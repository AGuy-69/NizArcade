/* ------------------------------------------------------------------
   ADD PROJECTS HERE.
   Each name must match the files inside the PROJECTS folder:
     PROJECTS/<name>.html         the embed (loaded in the player)
     PROJECTS/<name>.instruction  plain text shown under "Instructions"
     PROJECTS/<name>.png          the thumbnail
   Browsers can't list folders, so this array is the project list.
------------------------------------------------------------------- */
const PROJECTS = [
  "Bunny jump",
  "Advanced Engine Sim",
  "Submarine",
  "Asteroid shooter",
  "Protect the underwater",
  "Recycle Trash",
  "Game buang sampah wlee",
  "Trash Tycoon",
  "GreenSkyline",
  "Car Engine",
  "Fih",
  "Boating",
  "Dropper",
  "Stones n Boat",
  "cepatmakan",
  "Unicorn Rainbow Run Bottles Edition",
  "Bad Red",
  "Squirrel Game",
  "Birdy",
  "Squirell Fashion"
];

const $ = id => document.getElementById(id);
const path = (n, ext) => "PROJECTS/" + encodeURIComponent(n) + "." + ext;
const grid = $("grid");
let currentName = "";

function renderGrid(filter = "") {
  const q = filter.trim().toLowerCase();
  const list = PROJECTS.filter(n => n.toLowerCase().includes(q));
  grid.innerHTML = "";
  $("empty").hidden = list.length > 0;
  $("count").textContent = q
    ? `${list.length} of ${PROJECTS.length} projects`
    : `${PROJECTS.length} projects`;

  list.forEach(name => {
    const card = document.createElement("button");
    card.className = "card";
    card.innerHTML =
      '<div class="thumb"><span class="initial"></span><img alt="" loading="lazy"><span class="play">Play</span></div><h3></h3>';
    card.querySelector("h3").textContent = name;
    card.querySelector(".initial").textContent = name.trim().charAt(0).toUpperCase();
    const img = card.querySelector("img");
    img.src = path(name, "png");
    img.onerror = () => img.remove();   // falls back to the coloured initial
    card.onclick = () => { location.hash = "play=" + encodeURIComponent(name); };
    grid.appendChild(card);
  });
}

async function openProject(name) {
  currentName = name;
  $("home").hidden = true;
  $("player").hidden = false;
  $("p-title").textContent = name;
  document.title = name + " – Nizcade";
  window.scrollTo(0, 0);
  loadFrame(name);

  const inst = $("inst");
  inst.textContent = "Loading instructions…";
  try {
    const res = await fetch(path(name, "instruction"));
    if (!res.ok) throw new Error(res.status);
    const text = (await res.text()).trim();
    if (currentName === name) inst.textContent = text || "No instructions for this project.";
  } catch {
    if (currentName === name) inst.textContent = "No instructions for this project.";
  }
}

function loadFrame(name) {
  const f = $("frame");
  $("loader").hidden = false;
  f.onload = () => {
    if (f.src.endsWith("about:blank")) return;
    $("loader").hidden = true;
    f.focus();
  };
  f.src = "about:blank";
  setTimeout(() => { f.src = path(name, "html"); }, 30);
}

function closeProject() {
  currentName = "";
  $("frame").src = "about:blank";   // stops audio and the game
  $("player").hidden = true;
  $("home").hidden = false;
  document.title = "Nizcade";
}

function route() {
  const m = location.hash.match(/^#play=(.+)$/);
  const name = m && decodeURIComponent(m[1]);
  if (name && PROJECTS.includes(name)) openProject(name);
  else closeProject();
}

const restart = () => currentName && loadFrame(currentName);

$("search").oninput = e => renderGrid(e.target.value);
$("back").onclick = () => { location.hash = ""; };
$("home-link").onclick = e => { e.preventDefault(); location.hash = ""; };
$("reload").onclick = restart;
$("reload-fs").onclick = restart;
$("full").onclick = () => {
  document.fullscreenElement ? document.exitFullscreen() : $("stage").requestFullscreen();
};
$("unfull").onclick = () => document.exitFullscreen();
document.addEventListener("fullscreenchange", () => {
  const on = !!document.fullscreenElement;
  $("fs-tools").hidden = !on;
  $("full").textContent = on ? "Exit fullscreen" : "Fullscreen";
  if (!on) $("frame").focus();
});
window.onhashchange = route;

renderGrid();
route();
